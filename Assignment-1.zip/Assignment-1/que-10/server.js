console.log("Current file name:", __filename);
console.log("Current directory:", __dirname);

console.log("Process ID:", process.pid);
console.log("Node.js version:", process.version);
console.log("Platform:", process.platform);

global.myGlobalVar = "This is a global variable";

console.log("Accesing global variable:", myGlobalVar);

const timer = setTimeout(()=>{
    console.log("Timeout executed after 2 seconds");
}, 2000);

console.log("This is message using the global console object");