
# english-to-korean

A simple Node.js package to translate English text to Korean using LibreTranslate API.

## Installation

```bash
npm install english-to-korean
