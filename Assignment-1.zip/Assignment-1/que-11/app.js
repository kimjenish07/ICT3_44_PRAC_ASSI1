// If your package exports a function, for example:
const translateToKorean = require('./english-to-korean');

async function run() {
  const korean = await translateToKorean('Hello, how are you?');
  console.log(korean);  // Outputs Korean translation
}

run();
