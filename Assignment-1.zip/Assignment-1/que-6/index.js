const fs = require('fs');
const path = require('path');
const util = require('util');

const unlinkAsync = util.promisify(fs.unlink);

const fileToDelete = path.join(__dirname, 'text.txt');

unlinkAsync(fileToDelete)
.then(() => 
    console.log(`Deleted file: ${fileToDelete}`))
.catch(err => console.error('Error:', err.message));