function getResponse(message) {
    const msg = message.toLowerCase();

    if(msg.includes('hello') || msg.includes('hi')) {
        return 'Hi there! How can I assist you with your travel plans?';
    }
    else if (msg.includes('book flight')) {
        return 'Sure! I can help you book a flight. Where are you flying from and to?';
    }
    else if (msg.includes('recommed place')|| msg.includes('suggest place')) {
        return 'I recommend visiting Kyoto if you love culture and history!';
    }
    else if (msg.includes('hotel')) {
        return 'Would you prefer a budget or luxury hotel?';
    }
    else if (msg.includes('bye')) {
        return 'Safe travels! Let me know if you need anything else.';
    }
    else {
        return 'Sorry, I can only help with travel-related questions. Try asking about flights, hotels, or destinations.';
    }
}

module.exports = {getResponse};