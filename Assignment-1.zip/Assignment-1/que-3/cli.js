const readline = require('readline');
const {getResponse} = require('./chatbot');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'You> '
});

console.log('🌍 Travel Chatbot\nType your question below (type "exit" to quit)\n');
rl.prompt();

rl.on('line', (line) =>{
    const input = line.trim();
    if (input.toLowerCase() === 'exit') {
        console.log('Chatbot> Goodbye! 👋');
        rl.close();
    }
    else{
        const reply = getResponse(input);
        console.log('Chatbot> ' + reply);
        rl.prompt();
    }
});