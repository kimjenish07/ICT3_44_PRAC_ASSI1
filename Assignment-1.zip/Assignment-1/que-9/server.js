const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'example.txt');

fs.writeFile(filePath, "Anneyong !,this is some sample text!", (err) => {
    if (err) {
        return console.log('Error writing file:', err);
    }
    console.log('File written successfully.');

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            return console.error('Error reading file:', err);
        }
        console.log('File contents:', data);

        fs.appendFile(filePath, '\nAppending a new line.', (err) => {
            if (err) {
                return console.error('Error appending a file:', err);
            }
            console.log('Data appended successfully.');

            fs.readFile(filePath, 'utf8', (err, updatedData) => {
                if (err) {
                    return console.error('Error reading file:', err);
                }
                console.log('Updated file contents:', updatedData);


                /*fs.unlink(filePath, (err) => {
                    if (err) {
                        return console.error('Error deleting file:', err);
                    }
                    console.log('File deleted successfully.');

                });*/
            });
        });
    });
});