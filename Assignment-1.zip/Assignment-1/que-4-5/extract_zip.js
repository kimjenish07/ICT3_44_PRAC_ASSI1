const AdmZip = require("adm-zip");
const path = require("path");
const fs = require("fs");

function extractZip(zipFilePath, extractToPath){
    if(!fs.existsSync(zipFilePath)){
        console.error("Zip file does not exist:", zipFilePath);
        return;
    }
try{
    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo(extractToPath, true);
    console.log(`Extracted '${zipFilePath}' to '${extractToPath}' successfully.`);
}
catch(err){
    console.error("Failed to extract zip file.", err);
}
}
const zipPath = path.join(__dirname, "myFolder.zip");
const extractTo = path.join(__dirname, "Ext-myFolder");

extractZip(zipPath, extractTo);